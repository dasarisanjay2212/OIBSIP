# 🛡️ Python Dungeon Crawler

A lightweight, text-based Role-Playing Game (RPG) built entirely in Python. This project serves as an interactive demonstration of core **Object-Oriented Programming (OOP)** concepts, state management, and algorithmic game loops. 

## 📝 Description

In *Python Dungeon Crawler*, you step into the shoes of a hero tasked with surviving a gauntlet of increasingly difficult enemies. Manage your health, strategically use your limited potions, and rely on a bit of luck to defeat the Goblin, Orc, and the mighty Dragon to clear the dungeon.

This project was built to bridge the gap between basic Python syntax and structured software architecture. 

## ✨ Features

* **Turn-Based Combat:** Engage in tactical battles with a classic attack/heal/flee system.
* **Object-Oriented Architecture:** Code is structured using classes, inheritance, and encapsulation for clean, maintainable logic.
* **Randomized Damage & Outcomes:** Utilizes Python's `random` module for dynamic attack scaling and escape probability.
* **Zero Dependencies:** Built strictly using the Python Standard Library. No external packages required.

## 🚀 How to Run

### Prerequisites
You must have **Python 3.x** installed on your system. 

### Execution
1. Clone this repository or download the `rpg_game.py` file.
2. Open your terminal or command prompt.
3. Navigate to the directory containing the file.
4. Run the following command:

```bash
python rpg_game.py