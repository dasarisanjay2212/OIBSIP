import random
import time
import sys

# ==========================================
# 1. BASE CLASS (Encapsulation & Abstraction)
# ==========================================
class Entity:
    def __init__(self, name, max_hp, base_attack):
        self.name = name
        self.max_hp = max_hp
        self.hp = max_hp
        self.base_attack = base_attack

    def is_alive(self):
        return self.hp > 0

    def take_damage(self, damage):
        self.hp -= damage
        if self.hp < 0:
            self.hp = 0

    def attack_target(self, target):
        # Adds a slight variance to the attack damage (-2 to +5)
        damage = self.base_attack + random.randint(-2, 5)
        print(f"{self.name} attacks {target.name} for {damage} damage!")
        target.take_damage(damage)
        time.sleep(1)

# ==========================================
# 2. DERIVED CLASSES (Inheritance & Polymorphism)
# ==========================================
class Player(Entity):
    def __init__(self, name):
        # Initialize the base Entity class
        super().__init__(name, max_hp=100, base_attack=15)
        self.potions = 3

    def heal(self):
        if self.potions > 0:
            heal_amount = 30
            self.hp = min(self.max_hp, self.hp + heal_amount)
            self.potions -= 1
            print(f"{self.name} drinks a potion. Healed for {heal_amount}! (HP: {self.hp}/{self.max_hp})")
            print(f"Remaining potions: {self.potions}")
        else:
            print("You are out of potions! You lose your turn!")
        time.sleep(1)

class Enemy(Entity):
    def __init__(self, name, max_hp, base_attack):
        super().__init__(name, max_hp, base_attack)

# ==========================================
# 3. CORE GAME LOOP (State Management)
# ==========================================
def combat(player, enemy):
    print(f"\nA wild {enemy.name} appears!")
    time.sleep(1)

    while player.is_alive() and enemy.is_alive():
        print(f"\n--- {player.name}: {player.hp} HP | {enemy.name}: {enemy.hp} HP ---")
        print("1. Attack")
        print("2. Heal")
        print("3. Run")
        
        choice = input("Choose your action (1/2/3): ")
        print("-" * 40)

        # Player Turn
        if choice == '1':
            player.attack_target(enemy)
        elif choice == '2':
            player.heal()
        elif choice == '3':
            if random.random() > 0.5:
                print("You successfully ran away!")
                return True # Returned safely
            else:
                print("You tripped! Failed to escape.")
        else:
            print("Invalid input. You hesitated and lost your turn!")

        # Enemy Turn
        if enemy.is_alive():
            enemy.attack_target(player)

    # Combat Resolution
    if player.is_alive():
        print(f"\nYou defeated the {enemy.name}!")
        return True
    else:
        print("\nYou have been defeated... Game Over.")
        return False

# ==========================================
# 4. MAIN EXECUTION
# ==========================================
def main():
    print("=" * 40)
    print("WELCOME TO THE PYTHON DUNGEON")
    print("=" * 40)
    
    player_name = input("Enter your hero's name: ")
    player = Player(player_name)

    # List of enemies to fight consecutively
    enemies = [
        Enemy("Goblin", max_hp=30, base_attack=5),
        Enemy("Orc", max_hp=60, base_attack=10),
        Enemy("Dragon", max_hp=120, base_attack=18)
    ]

    for enemy in enemies:
        survived = combat(player, enemy)
        if not survived:
            sys.exit()
        
        # Heal slightly between battles
        if enemy != enemies[-1]:
            print("\nYou rest for a moment and recover 20 HP.")
            player.hp = min(player.max_hp, player.hp + 20)
            time.sleep(2)

    print("\nCONGRATULATIONS! You cleared the dungeon and became a legend!")

if __name__ == "__main__":
    main()