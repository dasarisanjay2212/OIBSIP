# Personal Expense Tracker

## Project Overview
This is a Command Line Interface (CLI) application built in Python that allows users to track their daily financial expenses. It is designed to be a practical, real-world utility that demonstrates core Python programming concepts.

## Features
* **Add Expenses:** Users can input an expense amount, categorize it (e.g., Food, Travel), and add a brief description. The program automatically logs the exact date and time.
* **View Expenses:** Displays all entered expenses in a clean, tabular format.
* **Category Summary:** Automatically calculates the total amount spent across all categories and provides a financial breakdown.
* **Data Persistence:** Uses File I/O to save expense data into a `expenses.json` file. Data is preserved even after the program is closed.
* **Error Handling:** Implements `try-except` blocks to prevent the application from crashing if a user enters incorrect data types (e.g., typing letters instead of numbers for the amount).

## Core Concepts Demonstrated
1. **Control Flow:** `while` loops for the main menu and `if-elif-else` conditions.
2. **Data Structures:** Uses Lists and Dictionaries to manage and group the data in memory.
3. **File I/O:** Utilizes the built-in `json` library to read and write data to external files.
4. **Modular Code:** Logic is broken down into reusable functions (`add_expense`, `view_expenses`, `view_summary`).

## How to Run
1. Ensure Python 3 is installed on your system.
2. Open a terminal or command prompt in the project directory.
3. Run the script using the command: `python main.py`