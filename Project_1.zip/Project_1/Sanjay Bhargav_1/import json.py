import json
import os
from datetime import datetime

# Define the file where data will be stored permanently
FILE_NAME = "expenses.json"

def load_expenses():
    if os.path.exists(FILE_NAME):
        with open(FILE_NAME, 'r') as file:
            return json.load(file)
    return []

def save_expenses(expenses):
    with open(FILE_NAME, 'w') as file:
        json.dump(expenses, file, indent=4)

def add_expense(expenses):
    try:
        amount = float(input("Enter expense amount: ₹"))
        category = input("Enter category (e.g., Food, Travel, Academics): ").strip().capitalize()
        description = input("Enter a short description: ").strip()
        # Automatically grab the current date and time
        date = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        expense = {
            "amount": amount,
            "category": category,
            "description": description,
            "date": date
        }
        expenses.append(expense)
        print("\nExpense added successfully!")
    except ValueError:
        print("\nError: Invalid amount. Please enter a numerical value.")

def view_expenses(expenses):
    if not expenses:
        print("\nNo expenses recorded yet.")
        return

    print("\n" + "-" * 70)
    print(f"{'Date':<20} | {'Category':<15} | {'Amount':<10} | {'Description'}")
    print("-" * 70)
    for exp in expenses:
        print(f"{exp['date']:<20} | {exp['category']:<15} | ₹{exp['amount']:<9.2f} | {exp['description']}")
    print("-" * 70)

def view_summary(expenses):
    if not expenses:
        print("\nNo expenses to summarize.")
        return

    summary = {}
    total = 0
    for exp in expenses:
        cat = exp['category']
        amt = exp['amount']
        # Add the amount to the specific category in the dictionary
        summary[cat] = summary.get(cat, 0) + amt
        total += amt

    print("\n--- Expense Summary by Category ---")
    for cat, amt in summary.items():
        print(f"{cat:<15}: ₹{amt:.2f}")
    print("-" * 35)
    print(f"Total Spent    : ₹{total:.2f}")

def main():
    expenses = load_expenses()

    while True:
        print("\n" + "="*35)
        print("PERSONAL EXPENSE TRACKER")
        print("="*35)
        print("1. Add an Expense")
        print("2. View All Expenses")
        print("3. View Category Summary")
        print("4. Exit and Save")

        choice = input("\nChoose an option (1-4): ").strip()

        if choice == '1':
            add_expense(expenses)
        elif choice == '2':
            view_expenses(expenses)
        elif choice == '3':
            view_summary(expenses)
        elif choice == '4':
            save_expenses(expenses)
            print("\nData saved successfully. Exiting the tracker. Goodbye! 👋")
            break
        else:
            print("\nInvalid choice. Please enter a number between 1 and 4.")

# Execute the program
if __name__ == "__main__":
    main()